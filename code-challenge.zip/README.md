Install it and run:

```bash
npm install
npm start
# or
yarn install
yarn start
```

Access the app at http://localhost:3001